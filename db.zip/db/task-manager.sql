-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 09, 2025 at 12:01 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `task-manager`
--

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2025_05_09_055139_create_tasks_table', 2),
(5, '2025_05_09_055705_create_personal_access_tokens_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('9ZZcoXZdCHPp66e8FPeoOFhqUCvXb0lcqXGMNxRg', NULL, '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidFRXNXY1Mm41Q1lYSkc2S1ExeERpWXUwelFYeHN2RUhmT1c3SGR3ZCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1746770252),
('PwUbn2B9ywlZhL9AEmFscZoc4nFE6uFsZo1k7iCj', NULL, '127.0.0.1', 'PostmanRuntime/7.37.3', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoid2t6bTBwRjlxZTBMc2tiTjBIazd5d2k0dWgycFdyZjJLRDVCRHlxVCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1746771592);

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('Pending','Completed') NOT NULL DEFAULT 'Pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `name`, `description`, `status`, `created_at`, `updated_at`) VALUES
(2, 'Sample Task 1', 'This is a sample description for task #1', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(3, 'Sample Task 2', 'This is a sample description for task #2', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(4, 'Sample Task 3', 'This is a sample description for task #3', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(5, 'Sample Task 4', 'This is a sample description for task #4', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(6, 'Sample Task 5', 'This is a sample description for task #5', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(7, 'Sample Task 6', 'This is a sample description for task #6', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(8, 'Sample Task 7', 'This is a sample description for task #7', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(9, 'Sample Task 8', 'This is a sample description for task #8', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(10, 'Sample Task 9', 'This is a sample description for task #9', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(11, 'Sample Task 10', 'This is a sample description for task #10', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(12, 'Sample Task 11', 'This is a sample description for task #11', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(13, 'Sample Task 12', 'This is a sample description for task #12', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(14, 'Sample Task 13', 'This is a sample description for task #13', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(15, 'Sample Task 14', 'This is a sample description for task #14', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(16, 'Sample Task 15', 'This is a sample description for task #15', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(17, 'Sample Task 16', 'This is a sample description for task #16', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(18, 'Sample Task 17', 'This is a sample description for task #17', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(19, 'Sample Task 18', 'This is a sample description for task #18', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(20, 'Sample Task 19', 'This is a sample description for task #19', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(21, 'Sample Task 20', 'This is a sample description for task #20', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(22, 'Sample Task 21', 'This is a sample description for task #21', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(23, 'Sample Task 22', 'This is a sample description for task #22', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(24, 'Sample Task 23', 'This is a sample description for task #23', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(25, 'Sample Task 24', 'This is a sample description for task #24', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(26, 'Sample Task 25', 'This is a sample description for task #25', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(27, 'Sample Task 26', 'This is a sample description for task #26', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(28, 'Sample Task 27', 'This is a sample description for task #27', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(29, 'Sample Task 28', 'This is a sample description for task #28', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(30, 'Sample Task 29', 'This is a sample description for task #29', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(31, 'Sample Task 30', 'This is a sample description for task #30', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(32, 'Sample Task 31', 'This is a sample description for task #31', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(33, 'Sample Task 32', 'This is a sample description for task #32', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(34, 'Sample Task 33', 'This is a sample description for task #33', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(35, 'Sample Task 34', 'This is a sample description for task #34', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(36, 'Sample Task 35', 'This is a sample description for task #35', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(37, 'Sample Task 36', 'This is a sample description for task #36', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(38, 'Sample Task 37', 'This is a sample description for task #37', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(39, 'Sample Task 38', 'This is a sample description for task #38', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(40, 'Sample Task 39', 'This is a sample description for task #39', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(41, 'Sample Task 40', 'This is a sample description for task #40', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(42, 'Sample Task 41', 'This is a sample description for task #41', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(43, 'Sample Task 42', 'This is a sample description for task #42', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(44, 'Sample Task 43', 'This is a sample description for task #43', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(45, 'Sample Task 44', 'This is a sample description for task #44', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(46, 'Sample Task 45', 'This is a sample description for task #45', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(47, 'Sample Task 46', 'This is a sample description for task #46', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(48, 'Sample Task 47', 'This is a sample description for task #47', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(49, 'Sample Task 48', 'This is a sample description for task #48', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(50, 'Sample Task 49', 'This is a sample description for task #49', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(51, 'Sample Task 50', 'This is a sample description for task #50', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(52, 'Sample Task 51', 'This is a sample description for task #51', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(53, 'Sample Task 52', 'This is a sample description for task #52', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(54, 'Sample Task 53', 'This is a sample description for task #53', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(55, 'Sample Task 54', 'This is a sample description for task #54', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(56, 'Sample Task 55', 'This is a sample description for task #55', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(57, 'Sample Task 56', 'This is a sample description for task #56', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(58, 'Sample Task 57', 'This is a sample description for task #57', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(59, 'Sample Task 58', 'This is a sample description for task #58', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(60, 'Sample Task 59', 'This is a sample description for task #59', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(61, 'Sample Task 60', 'This is a sample description for task #60', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(62, 'Sample Task 61', 'This is a sample description for task #61', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(63, 'Sample Task 62', 'This is a sample description for task #62', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(64, 'Sample Task 63', 'This is a sample description for task #63', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(65, 'Sample Task 64', 'This is a sample description for task #64', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(66, 'Sample Task 65', 'This is a sample description for task #65', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(67, 'Sample Task 66', 'This is a sample description for task #66', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(68, 'Sample Task 67', 'This is a sample description for task #67', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(69, 'Sample Task 68', 'This is a sample description for task #68', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(70, 'Sample Task 69', 'This is a sample description for task #69', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(71, 'Sample Task 70', 'This is a sample description for task #70', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(72, 'Sample Task 71', 'This is a sample description for task #71', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(73, 'Sample Task 72', 'This is a sample description for task #72', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(74, 'Sample Task 73', 'This is a sample description for task #73', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(75, 'Sample Task 74', 'This is a sample description for task #74', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(76, 'Sample Task 75', 'This is a sample description for task #75', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(77, 'Sample Task 76', 'This is a sample description for task #76', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(78, 'Sample Task 77', 'This is a sample description for task #77', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(79, 'Sample Task 78', 'This is a sample description for task #78', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(80, 'Sample Task 79', 'This is a sample description for task #79', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(81, 'Sample Task 80', 'This is a sample description for task #80', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(82, 'Sample Task 81', 'This is a sample description for task #81', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(83, 'Sample Task 82', 'This is a sample description for task #82', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(84, 'Sample Task 83', 'This is a sample description for task #83', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(85, 'Sample Task 84', 'This is a sample description for task #84', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(86, 'Sample Task 85', 'This is a sample description for task #85', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(87, 'Sample Task 86', 'This is a sample description for task #86', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(88, 'Sample Task 87', 'This is a sample description for task #87', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(89, 'Sample Task 88', 'This is a sample description for task #88', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(90, 'Sample Task 89', 'This is a sample description for task #89', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(91, 'Sample Task 90', 'This is a sample description for task #90', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(92, 'Sample Task 91', 'This is a sample description for task #91', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(93, 'Sample Task 92', 'This is a sample description for task #92', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(94, 'Sample Task 93', 'This is a sample description for task #93', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(95, 'Sample Task 94', 'This is a sample description for task #94', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(96, 'Sample Task 95', 'This is a sample description for task #95', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(97, 'Sample Task 96', 'This is a sample description for task #96', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(98, 'Sample Task 97', 'This is a sample description for task #97', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(99, 'Sample Task 98', 'This is a sample description for task #98', 'Completed', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(100, 'Sample Task 99', 'This is a sample description for task #99', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(101, 'Sample Task 100', 'This is a sample description for task #100', 'Pending', '2025-05-09 00:11:34', '2025-05-09 00:11:34'),
(102, 'My New Task', 'This is a test task', 'Pending', '2025-05-09 00:15:52', '2025-05-09 00:15:52');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
